
<?php
require_once __DIR__ . '/config/database.php';

// Helper function to generate random dates
function randomDate($startDate, $endDate) {
    $start = strtotime($startDate);
    $end = strtotime($endDate);
    $random = mt_rand($start, $end);
    return date('Y-m-d', $random);
}

try {
    // Start transaction
    $conn->begin_transaction();

    // 1. Create sample users
    $users = [
        // Admin user
        [
            'email' => 'admin@cameroonhotels.com',
            'password_hash' => password_hash('Admin123!', PASSWORD_BCRYPT),
            'first_name' => 'Admin',
            'last_name' => 'User',
            'role' => 'admin',
            'phone' => '+237677889900'
        ],
        // Staff user
        [
            'email' => 'staff@cameroonhotels.com',
            'password_hash' => password_hash('Staff123!', PASSWORD_BCRYPT),
            'first_name' => 'Staff',
            'last_name' => 'Member',
            'role' => 'staff',
            'phone' => '+237677889911'
        ],
        // Guest users
        [
            'email' => 'guest1@example.com',
            'password_hash' => password_hash('Guest123!', PASSWORD_BCRYPT),
            'first_name' => 'John',
            'last_name' => 'Doe',
            'role' => 'guest',
            'phone' => '+237677889922'
        ],
        [
            'email' => 'guest2@example.com',
            'password_hash' => password_hash('Guest123!', PASSWORD_BCRYPT),
            'first_name' => 'Jane',
            'last_name' => 'Smith',
            'role' => 'guest',
            'phone' => '+237677889933'
        ]
    ];

    foreach ($users as $user) {
        $stmt = $conn->prepare("INSERT INTO users (email, password_hash, first_name, last_name, phone, role) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", 
            $user['email'], 
            $user['password_hash'], 
            $user['first_name'], 
            $user['last_name'], 
            $user['phone'], 
            $user['role']);
        $stmt->execute();
        $userIds[$user['email']] = $stmt->insert_id;
    }

    // 2. Create room types
    $roomTypes = [
        [
            'name' => 'Standard Room',
            'description' => 'Comfortable room with basic amenities',
            'base_price' => 45000,
            'max_occupancy' => 2,
            'amenities' => json_encode(['WiFi', 'TV', 'AC', 'Safe'])
        ],
        [
            'name' => 'Deluxe Room',
            'description' => 'Spacious room with premium amenities',
            'base_price' => 75000,
            'max_occupancy' => 3,
            'amenities' => json_encode(['WiFi', 'TV', 'AC', 'Safe', 'Mini-bar', 'Coffee maker'])
        ],
        [
            'name' => 'Executive Suite',
            'description' => 'Luxurious suite with separate living area',
            'base_price' => 120000,
            'max_occupancy' => 4,
            'amenities' => json_encode(['WiFi', 'TV', 'AC', 'Safe', 'Mini-bar', 'Coffee maker', 'Jacuzzi'])
        ]
    ];

    foreach ($roomTypes as $type) {
        $stmt = $conn->prepare("INSERT INTO room_types (name, description, base_price, max_occupancy, amenities) 
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdis", 
            $type['name'], 
            $type['description'], 
            $type['base_price'], 
            $type['max_occupancy'], 
            $type['amenities']);
        $stmt->execute();
        $roomTypeIds[] = $stmt->insert_id;
    }

    // 3. Create hotels in Cameroon
    $cameroonHotels = [
        [
            'name' => 'Hilton Yaoundé',
            'description' => 'Luxury hotel in the heart of Yaoundé',
            'address' => 'Boulevard du 20 Mai, Yaoundé',
            'city' => 'Yaoundé',
            'country' => 'Cameroon',
            'postal_code' => '00237',
            'latitude' => 3.868986,
            'longitude' => 11.521334,
            'star_rating' => 5.0,
            'amenities' => json_encode(['Pool', 'Spa', 'Restaurant', 'Gym', 'Conference rooms']),
            'image' => 'https://example.com/hilton-yaounde.jpg'
        ],
        [
            'name' => 'Hotel Mont Fébé',
            'description' => 'Beautiful hotel with mountain views',
            'address' => 'Mont Fébé, Yaoundé',
            'city' => 'Yaoundé',
            'country' => 'Cameroon',
            'postal_code' => '00237',
            'latitude' => 3.891667,
            'longitude' => 11.506944,
            'star_rating' => 4.5,
            'amenities' => json_encode(['Pool', 'Restaurant', 'Garden']),
            'image' => 'https://example.com/mont-febe.jpg'
        ],
        [
            'name' => 'Sawa Hotel Douala',
            'description' => 'Modern hotel in the economic capital',
            'address' => 'Boulevard de la Liberté, Douala',
            'city' => 'Douala',
            'country' => 'Cameroon',
            'postal_code' => '00237',
            'latitude' => 4.051056,
            'longitude' => 9.704869,
            'star_rating' => 4.0,
            'amenities' => json_encode(['Pool', 'Restaurant', 'Bar', 'Business center']),
            'image' => 'https://example.com/sawa-douala.jpg'
        ],
        [
            'name' => 'Hotel La Falaise Bonapriso',
            'description' => 'Boutique hotel in Douala',
            'address' => 'Rue de Bonapriso, Douala',
            'city' => 'Douala',
            'country' => 'Cameroon',
            'postal_code' => '00237',
            'latitude' => 4.044722,
            'longitude' => 9.715556,
            'star_rating' => 4.0,
            'amenities' => json_encode(['Restaurant', 'Bar', 'Garden']),
            'image' => 'https://example.com/la-falaise.jpg'
        ],
        [
            'name' => 'Hotel Residence',
            'description' => 'Comfortable hotel in Buea',
            'address' => 'Molyko Street, Buea',
            'city' => 'Buea',
            'country' => 'Cameroon',
            'postal_code' => '00237',
            'latitude' => 4.166667,
            'longitude' => 9.233333,
            'star_rating' => 3.5,
            'amenities' => json_encode(['Restaurant', 'Bar']),
            'image' => 'https://example.com/residence-buea.jpg'
        ]
    ];

    foreach ($cameroonHotels as $hotel) {
        $stmt = $conn->prepare("INSERT INTO hotels (name, description, address, city, country, postal_code, 
                              latitude, longitude, star_rating, amenities, main_image_url) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssddsss", 
            $hotel['name'], 
            $hotel['description'], 
            $hotel['address'], 
            $hotel['city'], 
            $hotel['country'], 
            $hotel['postal_code'],
            $hotel['latitude'],
            $hotel['longitude'],
            $hotel['star_rating'],
            $hotel['amenities'],
            $hotel['image']);
        $stmt->execute();
        $hotelIds[] = $stmt->insert_id;
    }

    // 4. Assign staff to hotels
    foreach ($hotelIds as $hotelId) {
        $stmt = $conn->prepare("INSERT INTO staff_assignments (user_id, hotel_id, position, department, is_primary) 
                               VALUES (?, ?, 'Manager', 'Operations', TRUE)");
        $stmt->bind_param("ii", $userIds['staff@cameroonhotels.com'], $hotelId);
        $stmt->execute();
    }

    // 5. Create rooms for each hotel
    $roomNumbers = ['101', '102', '103', '201', '202', '203', '301', '302', '303'];
    foreach ($hotelIds as $hotelId) {
        foreach ($roomNumbers as $roomNumber) {
            $roomTypeId = $roomTypeIds[array_rand($roomTypeIds)];
            $floor = substr($roomNumber, 0, 1);
            $viewType = ['city', 'garden', 'pool', 'ocean', 'mountain'][rand(0, 4)];
            
            $stmt = $conn->prepare("INSERT INTO rooms (hotel_id, room_type_id, room_number, floor, view_type) 
                                   VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iisis", $hotelId, $roomTypeId, $roomNumber, $floor, $viewType);
            $stmt->execute();
            $roomIds[] = $stmt->insert_id;
        }
    }

    // 6. Create room availability for next 90 days
    foreach ($roomIds as $roomId) {
        $today = new DateTime();
        for ($i = 0; $i < 90; $i++) {
            $date = $today->add(new DateInterval('P1D'))->format('Y-m-d');
            $isAvailable = rand(0, 10) > 2; // 80% chance of being available
            
            $stmt = $conn->prepare("INSERT INTO room_availability (room_id, date, is_available) 
                                   VALUES (?, ?, ?)");
            $stmt->bind_param("isi", $roomId, $date, $isAvailable);
            $stmt->execute();
        }
    }

    // 7. Create sample reservations
    for ($i = 0; $i < 10; $i++) {
        $userId = $userIds[['guest1@example.com', 'guest2@example.com'][rand(0, 1)]];
        $roomId = $roomIds[array_rand($roomIds)];
        $checkIn = randomDate('now', '+30 days');
        $checkOut = randomDate($checkIn, '+7 days');
        $adults = rand(1, 3);
        $children = rand(0, 2);
        
        // Get base price from room type
        $stmt = $conn->prepare("SELECT rt.base_price FROM rooms r 
                               JOIN room_types rt ON r.room_type_id = rt.id 
                               WHERE r.id = ?");
        $stmt->bind_param("i", $roomId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $basePrice = $result['base_price'];
        
        // Calculate total price
        $days = (new DateTime($checkOut))->diff(new DateTime($checkIn))->days;
        $totalPrice = $basePrice * $days;
        
        $stmt = $conn->prepare("INSERT INTO reservations (user_id, room_id, check_in, check_out, 
                              adults, children, total_price, status) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, 'confirmed')");
        $stmt->bind_param("iissiid", $userId, $roomId, $checkIn, $checkOut, $adults, $children, $totalPrice);
        $stmt->execute();
        $reservationId = $stmt->insert_id;
        
        // Create payment record
        $stmt = $conn->prepare("INSERT INTO payments (reservation_id, amount, payment_method, status, payment_date) 
                               VALUES (?, ?, 'credit_card', 'completed', NOW())");
        $stmt->bind_param("id", $reservationId, $totalPrice);
        $stmt->execute();
        
        // Update room availability
        $stmt = $conn->prepare("UPDATE room_availability 
                               SET is_available = FALSE 
                               WHERE room_id = ? AND date BETWEEN ? AND DATE_SUB(?, INTERVAL 1 DAY)");
        $stmt->bind_param("iss", $roomId, $checkIn, $checkOut);
        $stmt->execute();
    }

    // Commit transaction
    $conn->commit();

    echo "Database successfully populated with:\n";
    echo "- " . count($users) . " users\n";
    echo "- " . count($roomTypes) . " room types\n";
    echo "- " . count($cameroonHotels) . " hotels in Cameroon\n";
    echo "- " . count($roomIds) . " rooms\n";
    echo "- 90 days of availability for each room\n";
    echo "- 10 sample reservations\n";

} catch (Exception $e) {
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}

$conn->close();