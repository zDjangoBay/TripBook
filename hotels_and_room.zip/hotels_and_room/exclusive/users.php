
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../middleware/logging.php';

header("Content-Type: application/json");

// Strict admin-only access
authenticate(['admin']);

$user_id = $_SESSION['user_id'];
$request_uri = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
$target_user_id = isset($request_uri[3]) ? (int)$request_uri[3] : null;

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // List all users (paginated)
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $users = $conn->query("
            SELECT id, email, role, created_at 
            FROM users 
            LIMIT $limit OFFSET $offset
        ")->fetch_all(MYSQLI_ASSOC);

        $total = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];

        echo json_encode([
            'data' => $users,
            'pagination' => [
                'page' => $page,
                'total_pages' => ceil($total / $limit)
            ]
        ]);
        break;

    case 'POST':
        // Create new user
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (empty($data['email']) || empty($data['password']) || empty($data['role'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Email, password and role are required']);
            exit;
        }

        // Validate role
        if (!in_array($data['role'], ['guest', 'staff', 'admin'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid role specified']);
            exit;
        }

        $stmt = $conn->prepare("
            INSERT INTO users (email, password_hash, role) 
            VALUES (?, ?, ?)
        ");
        $hashed_password = password_hash($data['password'], PASSWORD_BCRYPT);
        $stmt->bind_param("sss", $data['email'], $hashed_password, $data['role']);

        if ($stmt->execute()) {
            log_activity("User created by admin #$user_id: {$data['email']}");
            echo json_encode([
                'success' => true,
                'user_id' => $conn->insert_id
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'User creation failed']);
        }
        break;

    case 'PUT':
        // Update user (role/password)
        if (!$target_user_id) {
            http_response_code(400);
            echo json_encode(['error' => 'User ID required']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $updates = [];
        $params = [];
        $types = '';

        if (isset($data['role'])) {
            if (!in_array($data['role'], ['guest', 'staff', 'admin'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid role']);
                exit;
            }
            $updates[] = "role = ?";
            $params[] = $data['role'];
            $types .= 's';
        }

        if (isset($data['password'])) {
            $updates[] = "password_hash = ?";
            $params[] = password_hash($data['password'], PASSWORD_BCRYPT);
            $types .= 's';
        }

        if (empty($updates)) {
            http_response_code(400);
            echo json_encode(['error' => 'No valid fields to update']);
            exit;
        }

        $query = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
        $params[] = $target_user_id;
        $types .= 'i';

        $stmt = $conn->prepare($query);
        $stmt->bind_param($types, ...$params);

        if ($stmt->execute()) {
            log_activity("User #$target_user_id updated by admin #$user_id");
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Update failed']);
        }
        break;

    case 'DELETE':
        // Delete user (with safeguards)
        if (!$target_user_id) {
            http_response_code(400);
            echo json_encode(['error' => 'User ID required']);
            exit;
        }

        // Prevent self-deletion
        if ($target_user_id === $user_id) {
            http_response_code(403);
            echo json_encode(['error' => 'Cannot delete your own account']);
            exit;
        }

        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $target_user_id);

        if ($stmt->execute()) {
            log_activity("User #$target_user_id deleted by admin #$user_id");
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Deletion failed']);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
?>