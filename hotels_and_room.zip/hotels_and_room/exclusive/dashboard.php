
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../middleware/logging.php';

header("Content-Type: application/json");

// Restrict to staff and admin only
authenticate(['staff', 'admin']);

$user_role = $_SESSION['user_role'];
$user_id = $_SESSION['user_id'];
$date = isset($_GET['date']) ? $conn->real_escape_string($_GET['date']) : date('Y-m-d');

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Base query for today's operations
        $query = "
            SELECT 
                r.id as reservation_id,
                h.name as hotel_name,
                rm.type as room_type,
                u.email as guest_email,
                r.check_in,
                r.check_out,
                r.status
            FROM reservations r
            JOIN rooms rm ON r.room_id = rm.id
            JOIN hotels h ON rm.hotel_id = h.id
            JOIN users u ON r.user_id = u.id
            WHERE ? BETWEEN r.check_in AND r.check_out
        ";

        // Staff only see their assigned hotels
        if ($user_role === 'staff') {
            $query .= " AND h.id IN (
                SELECT hotel_id FROM staff_assignments WHERE staff_id = ?
            )";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("si", $date, $user_id);
        } else {
            // Admin sees all hotels
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $date);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        // Additional metrics for admin
        $response = [
            'date' => $date,
            'bookings' => $result->fetch_all(MYSQLI_ASSOC)
        ];

        if ($user_role === 'admin') {
            // Add financial metrics
            $revenue = $conn->query("
                SELECT SUM(rm.price) as daily_revenue
                FROM reservations r
                JOIN rooms rm ON r.room_id = rm.id
                WHERE '$date' BETWEEN r.check_in AND r.check_out
            ")->fetch_assoc();

            $response['metrics'] = [
                'daily_revenue' => $revenue['daily_revenue'] ?? 0,
                'occupancy_rate' => get_occupancy_rate($conn, $date)
            ];
        }

        echo json_encode($response);
        log_activity("Dashboard accessed by $user_role #$user_id");
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}

// Helper function
function get_occupancy_rate($conn, $date) {
    $total_rooms = $conn->query("SELECT COUNT(*) as total FROM rooms")->fetch_assoc()['total'];
    $booked_rooms = $conn->query("
        SELECT COUNT(DISTINCT room_id) as booked 
        FROM reservations 
        WHERE '$date' BETWEEN check_in AND check_out
    ")->fetch_assoc()['booked'];
    
    return round(($booked_rooms / $total_rooms) * 100, 2);
}
?>