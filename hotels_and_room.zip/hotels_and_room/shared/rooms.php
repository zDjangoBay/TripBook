
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../middleware/logging.php';

header("Content-Type: application/json");

authenticate(['guest', 'staff', 'admin']);

$user_role = $_SESSION['user_role'];
$hotel_id = isset($_GET['hotel_id']) ? (int)$_GET['hotel_id'] : null;

if (empty($hotel_id)) {
    http_response_code(400);
    echo json_encode(['error' => 'hotel_id parameter required']);
    exit;
}

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Basic room info for all, extended for staff/admin
        $select_fields = ($user_role === 'guest') 
            ? "id, type, price, amenities" 
            : "id, type, price, amenities, capacity, is_available";
        
        $stmt = $conn->prepare("
            SELECT $select_fields 
            FROM rooms 
            WHERE hotel_id = ?
        ");
        $stmt->bind_param("i", $hotel_id);
        $stmt->execute();
        
        echo json_encode($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
        break;

    case 'POST':
    case 'PUT':
        // Staff+admin can modify rooms
        if (!in_array($user_role, ['staff', 'admin'])) {
            http_response_code(403);
            echo json_encode(['error' => 'Insufficient privileges']);
            exit;
        }
        
        $data = json_decode(file_get_contents('php://input'), true);
        require_once __DIR__ . '/../handlers/room_operations.php';
        handle_room_update($conn, $hotel_id, $data, $_SERVER['REQUEST_METHOD']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
?>