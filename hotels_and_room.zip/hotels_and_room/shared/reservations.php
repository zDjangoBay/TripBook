
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../middleware/logging.php';

header("Content-Type: application/json");

authenticate(['guest', 'staff', 'admin']);

$user_role = $_SESSION['user_role'];
$user_id = $_SESSION['user_id'];

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Guests see only their reservations
        if ($user_role === 'guest') {
            $stmt = $conn->prepare("
                SELECT r.*, h.name as hotel_name 
                FROM reservations r
                JOIN rooms rm ON r.room_id = rm.id
                JOIN hotels h ON rm.hotel_id = h.id
                WHERE r.user_id = ?
            ");
            $stmt->bind_param("i", $user_id);
        } 
        // Staff see reservations for their hotels
        elseif ($user_role === 'staff') {
            $stmt = $conn->prepare("
                SELECT r.*, h.name as hotel_name 
                FROM reservations r
                JOIN rooms rm ON r.room_id = rm.id
                JOIN hotels h ON rm.hotel_id = h.id
                WHERE h.id IN (
                    SELECT hotel_id FROM staff_assignments WHERE staff_id = ?
                )
            ");
            $stmt->bind_param("i", $user_id);
        } 
        // Admin sees all
        else {
            $stmt = $conn->prepare("
                SELECT r.*, h.name as hotel_name 
                FROM reservations r
                JOIN rooms rm ON r.room_id = rm.id
                JOIN hotels h ON rm.hotel_id = h.id
            ");
        }
        
        $stmt->execute();
        echo json_encode($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
        break;

    case 'POST':
        // All roles can create reservations
        $data = json_decode(file_get_contents('php://input'), true);
        require_once __DIR__ . '/../handlers/create_reservation.php';
        handle_reservation_creation($conn, $data, $user_id);
        break;

    case 'PUT':
    case 'DELETE':
        // Only staff+admin can modify/cancel reservations
        if (!in_array($user_role, ['staff', 'admin'])) {
            http_response_code(403);
            echo json_encode(['error' => 'Staff/admin privileges required']);
            log_activity("Unauthorized reservation modification by $user_role #$user_id");
            exit;
        }
        
        $reservation_id = (int)$_GET['id'];
        require_once __DIR__ . '/../handlers/modify_reservation.php';
        handle_reservation_update($conn, $reservation_id, $_SERVER['REQUEST_METHOD']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
?>