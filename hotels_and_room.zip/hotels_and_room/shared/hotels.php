
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../middleware/logging.php';

header("Content-Type: application/json");

// Allow all authenticated users
authenticate(['guest', 'staff', 'admin']);

$user_role = $_SESSION['user_role'];
$user_id = $_SESSION['user_id'];

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // All roles can view hotels (with different filters)
        $query = "SELECT id, name, location, image_url, rating FROM hotels WHERE 1=1";
        
        // Staff only see hotels they're assigned to (if implemented)
        if ($user_role === 'staff') {
            $query .= " AND id IN (SELECT hotel_id FROM staff_assignments WHERE staff_id = $user_id)";
        }
        
        // Apply filters
        if (isset($_GET['location'])) {
            $location = $conn->real_escape_string($_GET['location']);
            $query .= " AND location LIKE '%$location%'";
        }
        
        $result = $conn->query($query);
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
        break;

    case 'POST':
    case 'PUT':
    case 'DELETE':
        // Only admin can modify hotels
        if ($user_role !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Admin privileges required']);
            log_activity("Unauthorized hotel modification attempt by $user_role #$user_id");
            exit;
        }
        
        require_once __DIR__ . '/../handlers/admin_hotel_operations.php';
        handle_hotel_modification($conn, $_SERVER['REQUEST_METHOD']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
?>