
<?php
$db_config = [
    'host' => getenv('DB_HOST') ?: 'localhost',
    'username' => getenv('DB_USER') ?: 'root',
    'password' => getenv('DB_PASS') ?: '',
    'database' => getenv('DB_NAME') ?: 'hotel_and_room',
    'port' => getenv('DB_PORT') ?: 3306,
    'charset' => 'utf8mb4'
];

$conn = new mysqli(
    $db_config['host'],
    $db_config['username'],
    $db_config['password'],
    $db_config['database'],
    $db_config['port']
);

if ($conn->connect_error) {
    log_error("Database connection failed: " . $conn->connect_error);
    die(json_encode(['error' => 'Database connection failed']));
}

$conn->set_charset($db_config['charset']);

// Helper function for prepared statements
function execute_query($conn, $sql, $params = [], $types = '') {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        log_sql_error($conn);
        return false;
    }
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    if (!$stmt->execute()) {
        log_sql_error($conn);
        return false;
    }
    
    return $stmt;
}
?>