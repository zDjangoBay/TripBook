
<?php
// Generate with: openssl rand -base64 32
define('JWT_SECRET', 'your_256_bit_secret_here_=');

// Token expiration times (in seconds)
define('JWT_ACCESS_EXPIRY', 3600);    // 1 hour
define('JWT_REFRESH_EXPIRY', 86400);  // 24 hours
?>