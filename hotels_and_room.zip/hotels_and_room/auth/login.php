<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt_secret.php'; // Stores JWT secret
require_once __DIR__ . '/../middleware/logging.php';

header("Content-Type: application/json");

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get and validate input
$data = json_decode(file_get_contents('php://input'), true);
if (empty($data['email']) || empty($data['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and password are required']);
    exit;
}

// Find user
$stmt = $conn->prepare("
    SELECT id, email, password_hash, role 
    FROM users 
    WHERE email = ? AND is_active = TRUE
");
$stmt->bind_param("s", $data['email']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Verify credentials
if (!$user || !password_verify($data['password'], $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid credentials']);
    log_activity("Failed login attempt for email: {$data['email']} from IP: {$_SERVER['REMOTE_ADDR']}");
    exit;
}

// Generate JWT token
$token = generate_jwt([
    'user_id' => $user['id'],
    'email' => $user['email'],
    'role' => $user['role'],
    'iat' => time(),
    'exp' => time() + (60 * 60 * 24) // 24 hour expiry
]);

// Update last login
$conn->query("UPDATE users SET last_login = NOW() WHERE id = {$user['id']}");

// Successful response
echo json_encode([
    'success' => true,
    'token' => $token,
    'user' => [
        'id' => $user['id'],
        'email' => $user['email'],
        'role' => $user['role']
    ]
]);

log_activity("Successful login for user #{$user['id']} ({$user['role']})");

// JWT Generation Function
function generate_jwt($payload) {
    $header = json_encode(['alg' => 'HS256', 'typ' => 'JWT']);
    $payload = json_encode($payload);
    
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
    
    $signature = hash_hmac('sha256', "$base64UrlHeader.$base64UrlPayload", JWT_SECRET, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    
    return "$base64UrlHeader.$base64UrlPayload.$base64UrlSignature";
}
?>