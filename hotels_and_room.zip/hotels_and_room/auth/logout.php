
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt_secret.php';
require_once __DIR__ . '/../middleware/logging.php';
require_once __DIR__ . '/../middleware/auth.php';

header("Content-Type: application/json");

authenticate(['guest', 'staff', 'admin']); // All roles can logout

$data = json_decode(file_get_contents('php://input'), true);
$token = $data['token'] ?? null;

if (empty($token)) {
    http_response_code(400);
    echo json_encode(['error' => 'Token required']);
    exit;
}

// Add token to blacklist (stored in Redis with remaining TTL)
$redis = new Redis();
$redis->connect('127.0.0.1');

$payload = validate_jwt($token, false);
if ($payload) {
    $ttl = $payload['exp'] - time();
    if ($ttl > 0) {
        $redis->setex("blacklist:$token", $ttl, '1');
    }
}

// Clear client-side token
echo json_encode([
    'success' => true,
    'message' => 'Logged out successfully'
]);

log_activity("User #{$_SESSION['user_id']} logged out");
?>