
<?php
require_once __DIR__ . '/../config/jwt_secret.php';
require_once __DIR__ . '/../middleware/logging.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (empty($data['token'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Token required']);
    exit;
}

// Validate existing token (without expiry check)
$token = validate_jwt($data['token'], false);

if (!$token) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid token']);
    exit;
}

// Generate new token with extended expiry
$new_token = generate_jwt([
    'user_id' => $token['user_id'],
    'email' => $token['email'],
    'role' => $token['role'],
    'iat' => time(),
    'exp' => time() + (60 * 60 * 24) // New 24-hour expiry
]);

echo json_encode([
    'success' => true,
    'token' => $new_token
]);

// JWT Validation Function (with optional expiry check)
function validate_jwt($jwt, $check_expiry = true) {
    $parts = explode('.', $jwt);
    if (count($parts) !== 3) return false;

    $signature = hash_hmac('sha256', "$parts[0].$parts[1]", JWT_SECRET, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    if ($base64UrlSignature !== $parts[2]) return false;

    $payload = json_decode(base64_decode($parts[1]), true);

    if ($check_expiry && (!isset($payload['exp']) || $payload['exp'] < time())) {
        return false;
    }

    return $payload;
}
?>