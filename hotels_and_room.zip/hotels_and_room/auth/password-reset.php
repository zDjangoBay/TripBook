<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../middleware/logging.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (empty($data['email'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Email required']);
    exit;
}

// Generate reset token (valid for 1 hour)
$reset_token = bin2hex(random_bytes(32));
$expiry = date('Y-m-d H:i:s', time() + 3600);

$stmt = $conn->prepare("
    UPDATE users 
    SET reset_token = ?, reset_expiry = ?
    WHERE email = ?
");
$stmt->bind_param("sss", $reset_token, $expiry, $data['email']);
$stmt->execute();

if ($conn->affected_rows === 1) {
    // In production, send email with reset link:
    // $reset_link = "https://your-api.com/auth/reset-password?token=$reset_token";
    // send_email($data['email'], "Password Reset", "Click here: $reset_link");
    
    echo json_encode([
        'success' => true,
        'message' => 'Reset instructions sent if email exists'
    ]);
} else {
    // Don't reveal if email exists
    echo json_encode([
        'success' => true,
        'message' => 'Reset instructions sent if email exists'
    ]);
}

log_activity("Password reset requested for: {$data['email']}");
?>