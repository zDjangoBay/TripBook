<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/middleware/auth.php';
require_once __DIR__ . '/middleware/logging.php';

class BackendTest {
    private $conn;
    private $baseUrl = 'http://localhost/hotels_and_room';
    private $adminToken;
    private $staffToken;
    private $guestToken;
    private $testHotelId;
    private $testRoomId;
    private $testReservationId;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->clearTestData();
    }

    private function clearTestData() {
        // Clear previous test data
        $tables = ['reservations', 'room_availability', 'rooms', 'staff_assignments', 'hotels', 'users'];
        foreach ($tables as $table) {
            $this->conn->query("DELETE FROM $table WHERE email LIKE '%@test.com' OR name LIKE 'Test%'");
        }
    }

    private function makeApiCall($method, $endpoint, $data = null, $token = null) {
        $url = $this->baseUrl . $endpoint;
        $headers = ['Content-Type: application/json'];
        
        if ($token) {
            $headers[] = "Authorization: Bearer $token";
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return [
            'code' => $httpCode,
            'response' => json_decode($response, true)
        ];
    }

    private function assert($condition, $message) {
        if ($condition) {
            echo "[PASS] $message\n";
        } else {
            echo "[FAIL] $message\n";
        }
    }

    public function runAllTests() {
        $this->testUserAuthentication();
        $this->testHotelOperations();
        $this->testRoomOperations();
        $this->testReservationWorkflow();
        $this->testAdminFunctions();
        $this->testErrorConditions();
    }

    private function testUserAuthentication() {
        echo "\n=== Testing Authentication ===\n";

        // Test admin login
        $response = $this->makeApiCall('POST', '/auth/login.php', [
            'email' => 'admin@cameroonhotels.com',
            'password' => 'Admin123!'
        ]);
        $this->adminToken = $response['response']['token'] ?? null;
        $this->assert($response['code'] === 200 && $this->adminToken, 'Admin login');

        // Test staff login
        $response = $this->makeApiCall('POST', '/auth/login.php', [
            'email' => 'staff@cameroonhotels.com',
            'password' => 'Staff123!'
        ]);
        $this->staffToken = $response['response']['token'] ?? null;
        $this->assert($response['code'] === 200 && $this->staffToken, 'Staff login');

        // Test guest login
        $response = $this->makeApiCall('POST', '/auth/login.php', [
            'email' => 'guest1@example.com',
            'password' => 'Guest123!'
        ]);
        $this->guestToken = $response['response']['token'] ?? null;
        $this->assert($response['code'] === 200 && $this->guestToken, 'Guest login');

        // Test invalid login
        $response = $this->makeApiCall('POST', '/auth/login.php', [
            'email' => 'invalid@test.com',
            'password' => 'wrong'
        ]);
        $this->assert($response['code'] === 401, 'Invalid login rejection');
    }

    private function testHotelOperations() {
        echo "\n=== Testing Hotel Operations ===\n";

        // Create test hotel (admin only)
        $hotelData = [
            'name' => 'Test Hotel Yaoundé',
            'address' => '123 Test Street, Yaoundé',
            'city' => 'Yaoundé',
            'country' => 'Cameroon',
            'star_rating' => 4
        ];
        $response = $this->makeApiCall('POST', '/shared/hotels.php', $hotelData, $this->adminToken);
        $this->testHotelId = $response['response']['hotel_id'] ?? null;
        $this->assert($response['code'] === 200 && $this->testHotelId, 'Hotel creation (admin)');

        // Try creating hotel as staff (should fail)
        $response = $this->makeApiCall('POST', '/shared/hotels.php', $hotelData, $this->staffToken);
        $this->assert($response['code'] === 403, 'Hotel creation rejection (staff)');

        // Get hotel list
        $response = $this->makeApiCall('GET', '/shared/hotels.php', null, $this->guestToken);
        $this->assert($response['code'] === 200 && !empty($response['response']), 'Hotel listing');
    }

    private function testRoomOperations() {
        echo "\n=== Testing Room Operations ===\n";

        // First create a room type (admin only)
        $roomTypeData = [
            'name' => 'Test Suite',
            'base_price' => 85000,
            'max_occupancy' => 3
        ];
        $response = $this->makeApiCall('POST', '/exclusive/room_types.php', $roomTypeData, $this->adminToken);
        $roomTypeId = $response['response']['room_type_id'] ?? null;
        $this->assert($response['code'] === 200 && $roomTypeId, 'Room type creation');

        // Create room in test hotel
        $roomData = [
            'hotel_id' => $this->testHotelId,
            'room_type_id' => $roomTypeId,
            'room_number' => 'TEST101',
            'floor' => 1,
            'view_type' => 'city'
        ];
        $response = $this->makeApiCall('POST', '/shared/rooms.php?hotel_id='.$this->testHotelId, $roomData, $this->staffToken);
        $this->testRoomId = $response['response']['room_id'] ?? null;
        $this->assert($response['code'] === 200 && $this->testRoomId, 'Room creation (staff)');

        // Get room list
        $response = $this->makeApiCall('GET', '/shared/rooms.php?hotel_id='.$this->testHotelId, null, $this->guestToken);
        $this->assert($response['code'] === 200 && !empty($response['response']), 'Room listing');
    }

    private function testReservationWorkflow() {
        echo "\n=== Testing Reservation Workflow ===\n";

        // Create reservation
        $reservationData = [
            'room_id' => $this->testRoomId,
            'check_in' => date('Y-m-d', strtotime('+3 days')),
            'check_out' => date('Y-m-d', strtotime('+5 days'))),
            'adults' => 2,
            'children' => 1
        ];
        $response = $this->makeApiCall('POST', '/shared/reservations.php', $reservationData, $this->guestToken);
        $this->testReservationId = $response['response']['reservation_id'] ?? null;
        $this->assert($response['code'] === 200 && $this->testReservationId, 'Reservation creation');

        // Get reservation details
        $response = $this->makeApiCall('GET', '/shared/reservations.php', null, $this->guestToken);
        $this->assert($response['code'] === 200 && !empty($response['response']), 'Reservation listing');

        // Staff view reservations
        $response = $this->makeApiCall('GET', '/shared/reservations.php', null, $this->staffToken);
        $this->assert($response['code'] === 200, 'Staff reservation access');

        // Cancel reservation
        $response = $this->makeApiCall('DELETE', '/shared/reservations.php?id='.$this->testReservationId, null, $this->staffToken);
        $this->assert($response['code'] === 200, 'Reservation cancellation');
    }

    private function testAdminFunctions() {
        echo "\n=== Testing Admin Functions ===\n";

        // Create test user
        $userData = [
            'email' => 'testuser@test.com',
            'password' => 'Test123!',
            'role' => 'staff',
            'first_name' => 'Test',
            'last_name' => 'User'
        ];
        $response = $this->makeApiCall('POST', '/exclusive/users.php', $userData, $this->adminToken);
        $this->assert($response['code'] === 200, 'User creation (admin)');

        // Get user list
        $response = $this->makeApiCall('GET', '/exclusive/users.php', null, $this->adminToken);
        $this->assert($response['code'] === 200 && !empty($response['response']['data'])), 'User listing');

        // Test dashboard access
        $response = $this->makeApiCall('GET', '/exclusive/dashboard.php', null, $this->adminToken);
        $this->assert($response['code'] === 200 && isset($response['response']['bookings']), 'Admin dashboard');
    }

    private function testErrorConditions() {
        echo "\n=== Testing Error Conditions ===\n";

        // Invalid token
        $response = $this->makeApiCall('GET', '/shared/hotels.php', null, 'invalidtoken');
        $this->assert($response['code'] === 401, 'Invalid token rejection');

        // Missing required fields
        $response = $this->makeApiCall('POST', '/auth/login.php', ['email' => 'test@test.com']);
        $this->assert($response['code'] === 400, 'Missing password rejection');

        // Unauthorized role access
        $response = $this->makeApiCall('GET', '/exclusive/users.php', null, $this->guestToken);
        $this->assert($response['code'] === 403, 'Guest accessing admin area');

        // Invalid date range
        $invalidReservation = [
            'room_id' => $this->testRoomId,
            'check_in' => date('Y-m-d', strtotime('+5 days'))),
            'check_out' => date('Y-m-d', strtotime('+3 days'))),
            'adults' => 2
        ];
        $response = $this->makeApiCall('POST', '/shared/reservations.php', $invalidReservation, $this->guestToken);
        $this->assert($response['code'] === 400, 'Invalid date range rejection');
    }
}

// Run tests
echo "=== Starting Backend Tests ===\n";
$test = new BackendTest($conn);
$test->runAllTests();
echo "\n=== Test Complete ===\n";