
<?php
function log_activity(string $message, string $log_type = 'access') {
    // Ensure logs directory exists
    $log_dir = __DIR__ . '/../../logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    // Sanitize log type
    $log_type = preg_replace('/[^a-z0-9_]/', '', strtolower($log_type));
    
    // Create log entry
    $log_entry = sprintf(
        "[%s] %s - IP: %s - UA: %s - User: %s\n",
        date('Y-m-d H:i:s'),
        $message,
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        $_SESSION['user_id'] ?? 'guest'
    );

    // Write to daily log file
    $log_file = "$log_dir/{$log_type}_" . date('Y-m-d') . '.log';
    file_put_contents($log_file, $log_entry, FILE_APPEND);

    // For errors, also log to PHP error log
    if ($log_type === 'error') {
        error_log($message);
    }
}

function log_error(string $message) {
    log_activity($message, 'error');
}

function log_sql_error(mysqli $conn) {
    if ($conn->error) {
        log_activity("SQL Error: {$conn->error}", 'error');
    }
}
?>