
<?php
function apply_rate_limit(string $action, int $max_attempts = 100, int $time_window = 60) {
    try {
        $redis = new Redis();
        $redis->connect('127.0.0.1', 6379, 1); // 1 second timeout
        
        // Key based on action and IP (or user ID if authenticated)
        $identifier = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        if (isset($_SESSION['user_id'])) {
            $identifier = 'user_' . $_SESSION['user_id'];
        }
        
        $key = "rate_limit:{$action}:{$identifier}";
        
        // Check current count
        $current = $redis->get($key) ?: 0;
        
        // Check if limit exceeded
        if ($current >= $max_attempts) {
            http_response_code(429);
            header('Retry-After: ' . $time_window);
            die(json_encode([
                'error' => 'Too many requests',
                'retry_after' => $time_window
            ]));
        }
        
        // Increment count
        $redis->multi();
        $redis->incr($key);
        $redis->expire($key, $time_window);
        $redis->exec();
        
        // Add rate limit headers to response
        header("X-RateLimit-Limit: $max_attempts");
        header("X-RateLimit-Remaining: " . ($max_attempts - $current - 1));
        header("X-RateLimit-Reset: " . (time() + $time_window));
        
    } catch (Exception $e) {
        // If Redis fails, log but don't block requests
        log_error("Rate limiting failed: " . $e->getMessage());
    }
}

// Specialized rate limiters
function apply_login_rate_limit() {
    apply_rate_limit('login', 5, 300); // 5 attempts per 5 minutes
}

function apply_api_rate_limit() {
    $role = $_SESSION['user_role'] ?? 'guest';
    
    // Different limits for different roles
    $limits = [
        'guest' => [100, 60],    // 100 requests/minute
        'staff' => [500, 60],    // 500 requests/minute
        'admin' => [1000, 60]    // 1000 requests/minute
    ];
    
    apply_rate_limit('api', ...$limits[$role]);
}
?>