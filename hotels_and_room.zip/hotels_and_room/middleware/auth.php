
<?php
require_once __DIR__ . '/../config/jwt_secret.php';
require_once __DIR__ . '/../config/database.php';

function authenticate(array $allowed_roles = []) {
    // Check for Authorization header
    if (!isset($_SERVER['HTTP_AUTHORIZATION'])) {
        http_response_code(401);
        die(json_encode(['error' => 'Authorization header missing']));
    }

    $auth_header = $_SERVER['HTTP_AUTHORIZATION'];
    $token = null;

    // Extract token from Bearer or just token
    if (preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
        $token = $matches[1];
    } else {
        $token = $auth_header;
    }

    if (!$token) {
        http_response_code(401);
        die(json_encode(['error' => 'Token not provided']));
    }

    // Validate JWT token
    $payload = validate_jwt($token);
    
    if (!$payload) {
        http_response_code(401);
        die(json_encode(['error' => 'Invalid or expired token']));
    }

    // Check token blacklist (Redis)
    $redis = new Redis();
    try {
        $redis->connect('127.0.0.1');
        if ($redis->exists("blacklist:$token")) {
            http_response_code(401);
            die(json_encode(['error' => 'Token revoked']));
        }
    } catch (Exception $e) {
        // Log but don't fail if Redis is down
        error_log("Redis connection failed: " . $e->getMessage());
    }

    // Check if user role is allowed
    if (!empty($allowed_roles)) {
        if (!in_array($payload['role'], $allowed_roles)) {
            http_response_code(403);
            die(json_encode(['error' => 'Insufficient privileges']));
        }
    }

    // Set user data in session for easy access
    $_SESSION['user_id'] = $payload['sub'];
    $_SESSION['user_email'] = $payload['email'];
    $_SESSION['user_role'] = $payload['role'];

    return $payload;
}

function validate_jwt(string $token, bool $check_expiry = true) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return false;
    }

    $header = base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[0]));
    $payload = base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1]));
    $signature = base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[2]));

    // Verify signature
    $calculated_signature = hash_hmac(
        'sha256',
        "$parts[0].$parts[1]",
        JWT_SECRET,
        true
    );

    if (!hash_equals($signature, $calculated_signature)) {
        return false;
    }

    $payload = json_decode($payload, true);

    // Check expiry if required
    if ($check_expiry && (!isset($payload['exp']) || $payload['exp'] < time())) {
        return false;
    }

    return $payload;
}

function generate_jwt(array $payload) {
    $header = json_encode(['alg' => 'HS256', 'typ' => 'JWT']);
    $payload = json_encode($payload);

    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

    $signature = hash_hmac('sha256', "$base64UrlHeader.$base64UrlPayload", JWT_SECRET, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    return "$base64UrlHeader.$base64UrlPayload.$base64UrlSignature";
}
?>