
<?php
require_once __DIR__ . '/../middleware/logging.php';

function handle_reservation_creation(mysqli $conn, array $data, int $user_id) {
    // Validate required fields
    $required = ['room_id', 'check_in', 'check_out', 'adults'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "$field is required"]);
            return;
        }
    }

    // Validate dates
    $check_in = DateTime::createFromFormat('Y-m-d', $data['check_in']);
    $check_out = DateTime::createFromFormat('Y-m-d', $data['check_out']);
    
    if (!$check_in || !$check_out || $check_in >= $check_out) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid date range']);
        return;
    }

    // Check room availability
    if (!is_room_available($conn, $data['room_id'], $data['check_in'], $data['check_out'])) {
        http_response_code(409);
        echo json_encode(['error' => 'Room not available for selected dates']);
        return;
    }

    // Calculate total price
    $total_price = calculate_reservation_price(
        $conn, 
        $data['room_id'], 
        $data['check_in'], 
        $data['check_out']
    );

    // Create reservation
    $stmt = $conn->prepare("
        INSERT INTO reservations (
            user_id, room_id, check_in, check_out,
            adults, children, total_price, special_requests
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "iissiids",
        $user_id,
        $data['room_id'],
        $data['check_in'],
        $data['check_out'],
        $data['adults'],
        $data['children'] ?? 0,
        $total_price,
        $data['special_requests'] ?? null
    );

    if ($stmt->execute()) {
        $reservation_id = $conn->insert_id;
        
        // Update room availability
        update_room_availability(
            $conn,
            $data['room_id'],
            $data['check_in'],
            $data['check_out'],
            false
        );
        
        // Create initial payment record
        create_payment_record($conn, $reservation_id, $total_price);
        
        log_activity("Reservation created: ID $reservation_id by user $user_id");
        echo json_encode([
            'success' => true,
            'reservation_id' => $reservation_id,
            'total_price' => $total_price
        ]);
    } else {
        log_sql_error($conn);
        http_response_code(500);
        echo json_encode(['error' => 'Failed to create reservation']);
    }
}

function is_room_available(mysqli $conn, int $room_id, string $check_in, string $check_out) {
    $stmt = $conn->prepare("
        SELECT COUNT(*) as unavailable_days
        FROM room_availability
        WHERE room_id = ?
          AND date BETWEEN ? AND DATE_SUB(?, INTERVAL 1 DAY)
          AND is_available = FALSE
    ");
    
    $stmt->bind_param("iss", $room_id, $check_in, $check_out);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    return $result['unavailable_days'] == 0;
}

function calculate_reservation_price(mysqli $conn, int $room_id, string $check_in, string $check_out) {
    // Get base price from room type
    $stmt = $conn->prepare("
        SELECT rt.base_price
        FROM rooms r
        JOIN room_types rt ON r.room_type_id = rt.id
        WHERE r.id = ?
    ");
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $room = $stmt->get_result()->fetch_assoc();
    
    $base_price = $room['base_price'];
    
    // Calculate number of nights
    $start = new DateTime($check_in);
    $end = new DateTime($check_out);
    $nights = $start->diff($end)->days;
    
    // Apply any seasonal pricing or discounts here if needed
    
    return $base_price * $nights;
}

function update_room_availability(mysqli $conn, int $room_id, string $check_in, string $check_out, bool $is_available) {
    $stmt = $conn->prepare("
        UPDATE room_availability
        SET is_available = ?
        WHERE room_id = ?
          AND date BETWEEN ? AND DATE_SUB(?, INTERVAL 1 DAY)
    ");
    
    $stmt->bind_param("iiss", $is_available, $room_id, $check_in, $check_out);
    $stmt->execute();
}

function create_payment_record(mysqli $conn, int $reservation_id, float $amount) {
    $stmt = $conn->prepare("
        INSERT INTO payments (
            reservation_id, amount, payment_method, status
        ) VALUES (?, ?, 'pending', 'pending')
    ");
    
    $stmt->bind_param("id", $reservation_id, $amount);
    $stmt->execute();
}
?>