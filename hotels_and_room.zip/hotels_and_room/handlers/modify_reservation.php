
<?php
require_once __DIR__ . '/../middleware/logging.php';

function handle_reservation_update(mysqli $conn, int $reservation_id, string $method) {
    switch ($method) {
        case 'PUT':
            update_reservation($conn, $reservation_id);
            break;
        case 'DELETE':
            cancel_reservation($conn, $reservation_id);
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
}

function update_reservation(mysqli $conn, int $reservation_id) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Get existing reservation details
    $stmt = $conn->prepare("
        SELECT room_id, check_in, check_out, status
        FROM reservations
        WHERE id = ?
    ");
    $stmt->bind_param("i", $reservation_id);
    $stmt->execute();
    $reservation = $stmt->get_result()->fetch_assoc();
    
    if (!$reservation) {
        http_response_code(404);
        echo json_encode(['error' => 'Reservation not found']);
        return;
    }
    
    // Only allow updates for certain statuses
    if (!in_array($reservation['status'], ['pending', 'confirmed'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Cannot modify reservation in current status']);
        return;
    }

    // Build dynamic update query
    $updates = [];
    $params = [];
    $types = '';
    
    $fields = [
        'check_in' => 's',
        'check_out' => 's',
        'adults' => 'i',
        'children' => 'i',
        'special_requests' => 's',
        'status' => 's'
    ];

    foreach ($fields as $field => $type) {
        if (array_key_exists($field, $data)) {
            $updates[] = "$field = ?";
            $params[] = $data[$field];
            $types .= $type;
        }
    }

    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => 'No valid fields to update']);
        return;
    }

    // If dates are being changed, verify availability
    if (isset($data['check_in']) || isset($data['check_out'])) {
        $new_check_in = $data['check_in'] ?? $reservation['check_in'];
        $new_check_out = $data['check_out'] ?? $reservation['check_out'];
        
        // First make the original dates available
        update_room_availability(
            $conn,
            $reservation['room_id'],
            $reservation['check_in'],
            $reservation['check_out'],
            true
        );
        
        // Check if new dates are available
        if (!is_room_available($conn, $reservation['room_id'], $new_check_in, $new_check_out)) {
            // Revert the availability change
            update_room_availability(
                $conn,
                $reservation['room_id'],
                $reservation['check_in'],
                $reservation['check_out'],
                false
            );
            
            http_response_code(409);
            echo json_encode(['error' => 'Room not available for new dates']);
            return;
        }
        
        // Update price if dates changed
        if (isset($data['check_in']) || isset($data['check_out'])) {
            $total_price = calculate_reservation_price(
                $conn,
                $reservation['room_id'],
                $new_check_in,
                $new_check_out
            );
            
            $updates[] = "total_price = ?";
            $params[] = $total_price;
            $types .= 'd';
        }
    }

    $params[] = $reservation_id;
    $types .= 'i';

    $sql = "UPDATE reservations SET " . implode(', ', $updates) . " WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        // If dates changed, update availability for new dates
        if (isset($data['check_in']) || isset($data['check_out'])) {
            update_room_availability(
                $conn,
                $reservation['room_id'],
                $new_check_in,
                $new_check_out,
                false
            );
        }
        
        log_activity("Reservation updated: ID $reservation_id");
        echo json_encode(['success' => true]);
    } else {
        log_sql_error($conn);
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update reservation']);
    }
}

function cancel_reservation(mysqli $conn, int $reservation_id) {
    // Get reservation details
    $stmt = $conn->prepare("
        SELECT room_id, check_in, check_out, status, payment_status
        FROM reservations
        WHERE id = ?
    ");
    $stmt->bind_param("i", $reservation_id);
    $stmt->execute();
    $reservation = $stmt->get_result()->fetch_assoc();
    
    if (!$reservation) {
        http_response_code(404);
        echo json_encode(['error' => 'Reservation not found']);
        return;
    }
    
    // Check if cancellation is allowed
    if (!in_array($reservation['status'], ['pending', 'confirmed'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Cannot cancel reservation in current status']);
        return;
    }

    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update room availability
        update_room_availability(
            $conn,
            $reservation['room_id'],
            $reservation['check_in'],
            $reservation['check_out'],
            true
        );
        
        // Update reservation status
        $stmt = $conn->prepare("
            UPDATE reservations
            SET status = 'cancelled',
                cancelled_at = NOW()
            WHERE id = ?
        ");
        $stmt->bind_param("i", $reservation_id);
        $stmt->execute();
        
        // Process refund if payment was made
        if ($reservation['payment_status'] === 'paid') {
            $stmt = $conn->prepare("
                UPDATE payments
                SET status = 'refunded',
                    refund_amount = amount,
                    refund_date = NOW()
                WHERE reservation_id = ?
                  AND status = 'completed'
            ");
            $stmt->bind_param("i", $reservation_id);
            $stmt->execute();
            
            $stmt = $conn->prepare("
                UPDATE reservations
                SET payment_status = 'refunded'
                WHERE id = ?
            ");
            $stmt->bind_param("i", $reservation_id);
            $stmt->execute();
        }
        
        $conn->commit();
        log_activity("Reservation cancelled: ID $reservation_id");
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        log_error("Failed to cancel reservation: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Failed to cancel reservation']);
    }
}

// Reuse these functions from create_reservation.php
function is_room_available(mysqli $conn, int $room_id, string $check_in, string $check_out) {
    // ... same implementation as in create_reservation.php ...
}

function calculate_reservation_price(mysqli $conn, int $room_id, string $check_in, string $check_out) {
    // ... same implementation as in create_reservation.php ...
}

function update_room_availability(mysqli $conn, int $room_id, string $check_in, string $check_out, bool $is_available) {
    // ... same implementation as in create_reservation.php ...
}
?>