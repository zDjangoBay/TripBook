
<?php
require_once __DIR__ . '/../middleware/logging.php';

function handle_hotel_modification(mysqli $conn, string $method) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    switch ($method) {
        case 'POST':
            create_hotel($conn, $data);
            break;
        case 'PUT':
            update_hotel($conn, $data);
            break;
        case 'DELETE':
            delete_hotel($conn, $_GET['id'] ?? null);
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
}

function create_hotel(mysqli $conn, array $data) {
    // Validate required fields
    $required = ['name', 'address', 'city', 'country'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "$field is required"]);
            return;
        }
    }

    // Prepare SQL
    $stmt = $conn->prepare("
        INSERT INTO hotels (
            name, description, address, city, state, 
            country, postal_code, latitude, longitude, 
            star_rating, amenities, main_image_url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    // Bind parameters
    $stmt->bind_param(
        "ssssssssddss",
        $data['name'],
        $data['description'] ?? null,
        $data['address'],
        $data['city'],
        $data['state'] ?? null,
        $data['country'],
        $data['postal_code'] ?? null,
        $data['latitude'] ?? null,
        $data['longitude'] ?? null,
        $data['star_rating'] ?? null,
        json_encode($data['amenities'] ?? []),
        $data['main_image_url'] ?? null
    );

    if ($stmt->execute()) {
        $hotel_id = $conn->insert_id;
        log_activity("Hotel created: ID $hotel_id");
        echo json_encode([
            'success' => true,
            'hotel_id' => $hotel_id
        ]);
    } else {
        log_sql_error($conn);
        http_response_code(500);
        echo json_encode(['error' => 'Failed to create hotel']);
    }
}

function update_hotel(mysqli $conn, array $data) {
    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Hotel ID is required']);
        return;
    }

    // Build dynamic update query
    $updates = [];
    $params = [];
    $types = '';
    
    $fields = [
        'name' => 's',
        'description' => 's',
        'address' => 's',
        'city' => 's',
        'state' => 's',
        'country' => 's',
        'postal_code' => 's',
        'latitude' => 'd',
        'longitude' => 'd',
        'star_rating' => 'd',
        'amenities' => 's',
        'main_image_url' => 's',
        'is_active' => 'i'
    ];

    foreach ($fields as $field => $type) {
        if (array_key_exists($field, $data)) {
            $updates[] = "$field = ?";
            $params[] = $field === 'amenities' ? json_encode($data[$field]) : $data[$field];
            $types .= $type;
        }
    }

    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => 'No valid fields to update']);
        return;
    }

    $params[] = $data['id'];
    $types .= 'i';

    $sql = "UPDATE hotels SET " . implode(', ', $updates) . " WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        log_activity("Hotel updated: ID {$data['id']}");
        echo json_encode(['success' => true]);
    } else {
        log_sql_error($conn);
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update hotel']);
    }
}

function delete_hotel(mysqli $conn, $hotel_id) {
    if (empty($hotel_id)) {
        http_response_code(400);
        echo json_encode(['error' => 'Hotel ID is required']);
        return;
    }

    // Soft delete (mark as inactive)
    $stmt = $conn->prepare("UPDATE hotels SET is_active = FALSE WHERE id = ?");
    $stmt->bind_param("i", $hotel_id);

    if ($stmt->execute()) {
        log_activity("Hotel deactivated: ID $hotel_id");
        echo json_encode(['success' => true]);
    } else {
        log_sql_error($conn);
        http_response_code(500);
        echo json_encode(['error' => 'Failed to delete hotel']);
    }
}
?>