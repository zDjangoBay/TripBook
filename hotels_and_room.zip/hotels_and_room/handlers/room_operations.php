
<?php
require_once __DIR__ . '/../middleware/logging.php';

function handle_room_update(mysqli $conn, int $hotel_id, array $data, string $method) {
    switch ($method) {
        case 'POST':
            create_room($conn, $hotel_id, $data);
            break;
        case 'PUT':
            update_room($conn, $hotel_id, $data);
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
}

function create_room(mysqli $conn, int $hotel_id, array $data) {
    // Validate required fields
    $required = ['room_type_id', 'room_number'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "$field is required"]);
            return;
        }
    }

    $stmt = $conn->prepare("
        INSERT INTO rooms (
            hotel_id, room_type_id, room_number, floor,
            view_type, is_smoking, is_accessible
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "iisisii",
        $hotel_id,
        $data['room_type_id'],
        $data['room_number'],
        $data['floor'] ?? null,
        $data['view_type'] ?? 'city',
        $data['is_smoking'] ?? 0,
        $data['is_accessible'] ?? 0
    );

    if ($stmt->execute()) {
        $room_id = $conn->insert_id;
        
        // Initialize room availability
        initialize_room_availability($conn, $room_id);
        
        log_activity("Room created: ID $room_id in Hotel $hotel_id");
        echo json_encode([
            'success' => true,
            'room_id' => $room_id
        ]);
    } else {
        log_sql_error($conn);
        http_response_code(500);
        echo json_encode(['error' => 'Failed to create room']);
    }
}

function update_room(mysqli $conn, int $hotel_id, array $data) {
    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Room ID is required']);
        return;
    }

    // Verify room belongs to hotel
    $stmt = $conn->prepare("SELECT id FROM rooms WHERE id = ? AND hotel_id = ?");
    $stmt->bind_param("ii", $data['id'], $hotel_id);
    $stmt->execute();
    
    if (!$stmt->get_result()->num_rows) {
        http_response_code(404);
        echo json_encode(['error' => 'Room not found in specified hotel']);
        return;
    }

    // Build dynamic update query
    $updates = [];
    $params = [];
    $types = '';
    
    $fields = [
        'room_type_id' => 'i',
        'room_number' => 's',
        'floor' => 'i',
        'view_type' => 's',
        'is_smoking' => 'i',
        'is_accessible' => 'i',
        'is_active' => 'i'
    ];

    foreach ($fields as $field => $type) {
        if (array_key_exists($field, $data)) {
            $updates[] = "$field = ?";
            $params[] = $data[$field];
            $types .= $type;
        }
    }

    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => 'No valid fields to update']);
        return;
    }

    $params[] = $data['id'];
    $types .= 'i';

    $sql = "UPDATE rooms SET " . implode(', ', $updates) . " WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        log_activity("Room updated: ID {$data['id']} in Hotel $hotel_id");
        echo json_encode(['success' => true]);
    } else {
        log_sql_error($conn);
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update room']);
    }
}

function initialize_room_availability(mysqli $conn, int $room_id) {
    // Create availability records for the next 365 days
    $stmt = $conn->prepare("
        INSERT INTO room_availability (room_id, date, is_available)
        SELECT ?, DATE_ADD(CURDATE(), INTERVAL n DAY), TRUE
        FROM (
            SELECT a.N + b.N*10 + c.N*100 AS n
            FROM 
                (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a,
                (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b,
                (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3) c
            WHERE a.N + b.N*10 + c.N*100 < 365
        ) numbers
    ");
    
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
}
?>